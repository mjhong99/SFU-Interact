Readme Instruction:


The left sidebar of the home page enables you to visit every single page and see the detailed layout.

To access the course content page, click the course content page tab. Click on the details button to access a more detailed course content page. 

To access the Video meeting page, click on the video meeting tab. You will be presented with the chat window, notes feature, and slides feature. Using the chat window, our system only provides default messages as we have not implemented the whole functionality of messaging users. Clicking on the send button will show a message from a “normal user”. Clicking on the “anon” button will show a message from an anonymous user.

To interact with the Slides feature, press the “+” sign to open a window. From there you can use the “<” and “>” to move across slides. The “X” button will close the slides feature.

To interact with the notes feature, press the “+” sign to open a window. You can type anything in the box. To save your notes, press the “send” icon (airplane). Once you click on the send button, a popup in the next window will indicate that your notes have been saved. We have not implemented the functionality where your notes will be saved in the notes page. 

You can access the recording page by clicking on the recording tab.
You can access the message page by clicking on the message tab. You can click on the “person (2 people)” icon to switch between messaging interfaces.

On the discussion forum page, clicking the ‘+’ sign  on the top right will create the new discussion topic as the user wishes. After clicking the ‘post’ button, the new discussion topic will show on the bottom of the page.

By clicking any discussions on the discussion forum page, it will then show the discussion channel for each question. Text channel is for group chatting. If necessary, the users can join the voice channel to discuss orally.
